var mysqlConnection=require('./config');
var express=require("express");
var app = express(); 
const bodyParser=require('body-parser');
var path=require('path');

app.use(bodyParser.urlencoded({extended:true}));
app.use(bodyParser.json());
app.use('/validation',express.static(__dirname+'/JS'));
app.use('/CSS',express.static(__dirname+'/CSS'));
app.use('/bootstrap',express.static(__dirname+'/bootstrap/css'));
 app.get('/view',function(req,res){
    res.sendFile(path.join(__dirname+'/edit.html'));
 });
 var ID;
 app.listen(3001,()=>console.log("Express server is running at : 3001"));

 app.post('/top',function(req,res){
   var mobno=req.body.Mobno;
   var sql=`select * from stud_tb where mobno="`+mobno+`"`;
   mysqlConnection.query(sql, function (err, result) {
     if (!err)
    {
      if(result[0]!=undefined){
      var id=result[0].id;
      ID=id;
      var name=result[0].name;
      var fname=result[0].fname;
      var postaladdr=result[0].postal_addr;
      var personaladdr=result[0].personal_addr;
      var sex=result[0].sex;
      var city=result[0].city
      var district=result[0].district;
      var pincode=result[0].pincode;
      var email=result[0].email;
      var mobno=result[0].mobno;
      var state=result[0].state;
      var course=result[0].course;

         res.writeHead(200, {'Content-Type': 'text/html'});
         res.write(`
         <!DOCTYPE html>
         <html lang="en">
         <head>
         <meta charset="UTF-8">
         <meta name="viewport" content="width=device-width, initial-scale=1.0">
         <link rel="stylesheet" href="/CSS/Style.css">
         <link rel="stylesheet" href="/bootstrap/bootstrap.min.css">
         <title>Student Registration</title>
         <script type="text/javascript">
  function validation() {
  var user=document.getElementById("name").value;
  var fname=document.getElementById("fathername").value;
  var Email = document.getElementById('Email').value;
  var Mobno=document.getElementById('Mobno').value;

  document.getElementById('mobno').innerHTML="";
  if( Mobno==""|| isNaN(Mobno) || Mobno.length != 10)
  {
  document.getElementById('mobno').innerHTML="Mobile No should be in the format ###."
  document.getElementById('Mobno').focus();
  counter=1;
  }   

   atpos = Email.indexOf("@");
  dotpos = Email.lastIndexOf(".");
  document.getElementById('email').innerHTML="";
  if (Email == "" || atpos < 1 || ( dotpos - atpos < 2 )) 
 {
    document.getElementById('email').innerHTML="Please provide correct Email ID!"
     document.getElementById('Email').focus() ;
     counter=1;
 }

/*----------------------------------------------------------------------------*/

var Pincode=document.getElementById('Pincode').value

  document.getElementById('pincode').innerHTML="";
  if(Pincode==""|| isNaN(Pincode) || Pincode.length!=6)
  {
    document.getElementById('pincode').innerHTML="Pincode should be in ######." 
    document.getElementById('Pincode').focus();
    counter=1;
  }
   
/*-------------------------------------------------------------------*/

  document.getElementById('fname').innerHTML="";
  if(fname=="" || fname==null)
  { 
    document.getElementById('fname').innerHTML="**Please fill Fathers name";
    document.getElementById('fathername').focus();
    counter=1;
  }

  if(!isNaN(fname) && fname!="")
  {
    document.getElementById('fname').innerHTML="**Only Characters are allowed";
    counter=1;
  }

  document.getElementById('username').innerHTML="";
if(user==""|| user==null)
{
  document.getElementById('username').innerHTML="**Please fill name";
  document.getElementById('name').focus();
  counter=1;
}
if(!isNaN(user) && user!="")
{
  document.getElementById('username').innerHTML="**Only Characters are allowed";
  counter=1;
}
if (counter==1)
return false;
else
return true;
}    
         </script>
         </head>
            <body style="background-color:black;">
           <form action="/submit" name="StudentRegistration" onSubmit="return validation()" method="POST">
           <table cellpadding="8" align="center" cellspacing="8" id="outertable" >
           <tr>
             <td colspan="3">
             <center><font size=5><b>Edit Your Details</b></font></center>    
             </td>
             </tr>
             
             <tr>
              <td>Name<span class="text-danger">*</span></td>
              <td><input type=text name=name id="name" value="`+name+`" size="30" required> 
              <span id='username' class="text-danger font-weight-Bold"></span> </td> 
            </tr>
            
            
            <tr>
              <td>Father Name<span class="text-danger">*</span></td>
              <td><input type="text" name="fathername" id="fathername" value="`+fname+`"
              size="30" required>
              <span id='fname' class="text-danger font-weight-Bold"></span>
              </td>
              </td>
            </tr>
            
              <tr>
              <td>Postal Address</td>
              <td><input type="text" name="paddress" id="paddress" value="`+postaladdr+`" size="30">
              <span id='postaladdr' class="text-danger font-weight-Bold"></span>
              </td>
              </tr>
            
            <tr>
              <td>Personal Address<span class="text-danger">*</span></td>
              <td><input type="text" name="personaladdress"
              id="personaladdress"  value="`+personaladdr+`" size="30" required>
              <span id='personaladdr' class="text-danger font-weight-Bold"></span>
            </td>
            </tr>
            
            <tr>
              <td>Sex</td>
              <td><input type="text" name="sex" value="`+sex+`" size="10">
              <span id='sex' class="text-danger font-weight-Bold"></span>
            </td>
              </tr>
            
            <tr>
              <td>City<span class="text-danger">*</span></td>
              <td><input type="text" name="city" id="City" value="`+city+`" size="30" required>
                <span id='city' class="text-danger font-weight-Bold"></span></td>
            </tr>
          
            <tr>
              <td>District<span class="text-danger">*</span></td>
              <td><input type="text" name="district" id="District" size="30" value="`+district+`" required>
                <span id='district' class="text-danger font-weight-Bold"></span>
              </td>
            </tr>
            
            
            <tr> 
              <td>State<span class="text-danger">*</span></td>
              <td><input Name="state" id="State" value="`+state+`" required>
              </select>
              <span id='state' class="text-danger font-weight-Bold"></span>
            </td>
              </tr>
            
            <tr>
              <td>PinCode<span class="text-danger">*</span></td>
              <td><input type="text" name="pincode" id="Pincode" size="10" value="`+pincode+`" required>
                <span id='pincode' class="text-danger font-weight-Bold"></span>
              </td>
            </tr>
    
            <tr>
              <td>Course<span class="text-danger">*</span></td>
              <td><input type="text" name="course" id="Course" value="`+course+`" required>
              <span id='course' class="text-danger font-weight-Bold"></span>
            </td>
            </tr>
    
            <tr>
              <td>Email-Id<span class="text-danger">*</span></td>
              <td><input type="text" name="emailid" id="Email" size="30" value="`+email+`" required>
              <span id='email' class="text-danger font-weight-Bold"></span>
              </td>
            </tr>
            
            <tr>
              <td>MobileNo<span class="text-danger">*</span></td>
              <td><input type="text" name="mobileno" id="Mobno" size="30" value="`+mobno+`" required>
                <span id='mobno' class="text-danger font-weight-Bold"></span>
              </td>
            </tr>
            
            <tr>
              <td align="center"></td>
              <td ><input type="submit" value="submit" id="submit"/></td>  
            </tr>`
             );
    return res.end();
    }
    else
    {
      res.writeHead(200, {'Content-Type': 'text/html'});
         res.write(`
         <!DOCTYPE html>
         <html lang="en">
         <head>
         <meta charset="UTF-8">
         <meta name="viewport" content="width=device-width, initial-scale=1.0">
         <link rel="stylesheet" href="/CSS/Style.css">
         <link rel="stylesheet" href="/bootstrap/bootstrap.min.css">
         <title>Student Registration</title>
         </head>
         
         <body style="background-color:black;">
        <form action="/submit" name="StudentRegistration" onSubmit="return validation()" method="POST">
        <table cellpadding="8" align="center" cellspacing="8" id="outertable" >
        <tr>
          <td colspan="3">
          <center><font size=5><b>Record is not present in Database.Please enter correct Mobile number</b></font></center>    
          </td>
          </tr>
        `);
       }
       return res.end;  
        console.log(err);
        }
    });
    });

    app.post('/submit',function(req,res){
       console.log("ID ="+ID); 
      var name=req.body.name;
        var fname=req.body.fathername;
        var postaladdr= req.body.paddress;
        var personaladdr= req.body.personaladdress;
        var sex= req.body.sex;
        var city=req.body.city;
        var district=req.body.district;
        var state=req.body.state;
        var pincode=req.body.pincode;
        var course=req.body.course;
        var email=req.body.emailid;
        var mobno=req.body.mobileno;
    
        //var sql = `INSERT INTO stud_tb (name,fname,postal_addr,personal_addr,sex,city,district,state,pincode,course,email,dob,mobno) VALUES ("`+name+`","`+fname+`","`+postaladdr+`","`+personaladdr+`","`+sex+`","`+city+`","`+district+`","`+state+`","`+pincode+`","`+course+`","`+email+`","`+dob+`","`+mobno+`")`; 
        var sql= `UPDATE stud_tb SET name = "`+name+`", fname = "`+fname+`", personal_addr="`+personaladdr+`",postal_addr="`+postaladdr+`",sex="`+sex+`",city="`+city+`",district="`+district+`",state="`+state+`",pincode="`+pincode+`",course="`+course+`",email="`+email+`",mobno="`+mobno+`" 
        WHERE id="`+ID+`"`;
         mysqlConnection.query(sql, function (err, result) {
            if (err) throw err;
            console.log("Record Updated successfully");
        });
        return res.redirect('http://localhost:3000/student');
        res.end();
      });

      app.post('/bottom',function(req,res){
        var mobno=req.body.mobno1;
        var sql=`DELETE FROM stud_tb WHERE mobno="`+mobno+`"`;
        mysqlConnection.query(sql, function (err, result) {
          if (!err)
         {
          console.log("Your Record deleted successfully");         
         }
         else 
         console.log(err);
      });
      return res.redirect('http://localhost:3000/student');
      res.end();
    });