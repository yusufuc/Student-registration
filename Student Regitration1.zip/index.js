//var mysql = require('mysql');
var mysqlConnection = require('./config');
var express=require("express");
var app = express(); 
const bodyParser=require('body-parser');
var path=require('path');

app.use(bodyParser.urlencoded({extended:true}));
app.use(bodyParser.json());
app.use('/CSS',express.static(__dirname+'/CSS'));
app.use('/validation',express.static(__dirname+'/JS'));
app.use('/bootstrap',express.static(__dirname+'/bootstrap/css'));


/*---------------------------------------Database connection---------------------------------------*/
/*var mysqlConnection=mysql.createConnection({
host :'localhost',
user :'root',
password :'Yu$uf123', 
database : 'studentdb'
});

mysqlConnection.connect(function(err){
  if(!err) {
      console.log("Database is connected");
  } else {
      console.log("Error while connecting with database");
  }
  });
  */
app.get('/student',function(req,res){
    res.sendFile(path.join(__dirname+'/index.html'));
});

/*----------------------------------------Routing----------------------------------------------------*/

  app.post('/submit',function(req,res){

 var name=req.body.name;
  var fname=req.body.fathername;
  var postaladdr= req.body.paddress;
  var personaladdr= req.body.personaladdress;
  var sex= req.body.sex;
  var city=req.body.city;
  var district=req.body.district;
  var state=req.body.state;
  var pincode=req.body.pincode;
  var course=req.body.course;
  var email=req.body.emailid;
  var dob=req.body.dob;
  var mobno=req.body.mobileno;

  var board1=req.body.board1;
  var perc1=req.body.perc1;
  var yop1=req.body.yop1;

  var board2=req.body.board2;
  var perc2=req.body.perc2;
  var yop2=req.body.yop2;
  
  var board3=req.body.board3;
  var perc3=req.body.perc3;
  var yop3=req.body.yop3;
  
var sql = `INSERT INTO stud_tb (name,fname,postal_addr,personal_addr,sex,city,district,state,pincode,course,email,dob,mobno,10_b,12_b,Grad_b,10_p,12_p,Grad_p,10_yop,12_yop,Grad_yop) VALUES ("`+name+`","`+fname+`","`+postaladdr+`","`+personaladdr+`","`+sex+`","`+city+`","`+district+`","`+state+`","`+pincode+`","`+course+`","`+email+`","`+dob+`","`+mobno+`","`+board1+`","`+board2+`","`+board3+`","`+perc1+`","`+perc2+'","'+perc3+'","'+yop1+'","'+yop2+'","'+yop3+`")`; 


 mysqlConnection.query(sql, function (err, result) {
    if (err) throw err;
    console.log("Record inserted successfully");
});
return res.redirect('http://localhost:3000/student');
res.end()
 }); 


app.listen(3000,()=>console.log("Express server is running at : 3000"));
