function validation()
{
  var user=document.getElementById("name").value;
  var fname=document.getElementById("fathername").value;
  var postal=document.getElementById("paddress").value;
  var personal=document.getElementById("personaladdress").value;
  var counter=0;

  /*----------------------------------------------------*/
var Board3=document.getElementById('Board3').value
var Perc3=document.getElementById('Perc3').value
var YOP3=document.getElementById('YOP3').value

document.getElementById('yop').innerHTML="";
document.getElementById('perc').innerHTML="";
document.getElementById('board').innerHTML="";

if(YOP3=="" || YOP3==null)
{
 document.getElementById('yop').innerHTML="*Please fill your passout year";
 document.getElementById('YOP3').focus();
  counter=1;
}
if(isNaN(YOP3))
{
  document.getElementById('yop').innerHTML="*characters are not valid";
  document.getElementById('YOP3').focus();
  counter=1;
}

if(Perc3=="" || Perc3==null)
{
 document.getElementById('perc').innerHTML="*fill your Grad. Percentage";
 document.getElementById('Perc3').focus();
  counter=1;
}

if(isNaN(Perc3))
{
  document.getElementById('perc').innerHTML="*characters are not valid";
 document.getElementById('Perc3').focus();
  counter=1;
}

if(Board3=="" || Board3==null)
{ 
 document.getElementById('board').innerHTML="*Please fill your University";
 document.getElementById('Board3').focus();
  counter=1;
}


/*--------------------------------------------------------------------*/

var Board2=document.getElementById('Board2').value
var Perc2=document.getElementById('Perc2').value
var YOP2=document.getElementById('YOP2').value

if(YOP2=="" || YOP2==null)
{
 document.getElementById('yop').innerHTML="*fill your XII passout year";
 document.getElementById('YOP2').focus();
 counter=1;
}
if(isNaN(YOP2))
{
  document.getElementById('yop').innerHTML="*characters are not valid";
  document.getElementById('YOP2').focus();
  counter=1;
}

if(Perc2=="" || Perc2==null)
{
 document.getElementById('perc').innerHTML="*fill your XII Percentage";
 document.getElementById('Perc2').focus();
 counter=1;
}
if(isNaN(Perc2))
{
  document.getElementById('perc').innerHTML="*characters are not valid";
 document.getElementById('Perc2').focus();
 counter=1;
}

if(Board2=="" || Board2==null)
{ 
 document.getElementById('board').innerHTML="*fill your XII Board";
 document.getElementById('Board2').focus();
 counter=1;
}

/*-----------------------------------------------------------*/

var Board1=document.getElementById('Board1').value
var Perc1=document.getElementById('Perc1').value
var YOP1=document.getElementById('YOP1').value

if(YOP1=="" || YOP1==null)
{
 document.getElementById('yop').innerHTML="*fill your X passout year";
 document.getElementById('YOP1').focus();
  counter=1;
}
if(isNaN(YOP1))
{
  document.getElementById('yop').innerHTML="*characters are not valid";
  document.getElementById('YOP1').focus();
  counter=1;
}


if(Perc1=="" || Perc1==null)
{
 document.getElementById('perc').innerHTML="*Please fill your X Percentage";
 document.getElementById('Perc1').focus();
  counter=1;
}

if(isNaN(Perc1))
{
  document.getElementById('perc').innerHTML="*characters are not valid";
 document.getElementById('Perc1').focus();
  counter=1;
}

if(Board1=="" || Board1==null)
{
 document.getElementById('board').innerHTML="*Please fill your X Board";
 document.getElementById('Board1').focus();
  counter=1;
}

  
/*-------------------------------------------------------------------------------------------------*/



  

  /*--------------------------------------------------------------------------------------------------*/

  var Course=document.getElementById('Course').value
  var Email = document.getElementById('Email').value;
  var DOB=document.getElementById('DOB').value
  var Mobno=document.getElementById('Mobno').value;

  document.getElementById('mobno').innerHTML="";
  if( Mobno==""|| isNaN(Mobno) || Mobno.length != 10)
  {
  document.getElementById('mobno').innerHTML="Mobile No should be in the format ###."
  document.getElementById('Mobno').focus();
  counter=1;
  }   

 document.getElementById('dob').innerHTML="";
  if(DOB=="")
   {
    document.getElementById('dob').innerHTML="Please provide Date Of Birth!"
    document.getElementById('DOB').focus(); 
    counter=1;
   }
/*-----------------------------------*/
   atpos = Email.indexOf("@");
  dotpos = Email.lastIndexOf(".");
  document.getElementById('email').innerHTML="";
  if (Email == "" || atpos < 1 || ( dotpos - atpos < 2 )) 
 {
    document.getElementById('email').innerHTML="Please provide correct Email ID!"
     document.getElementById('Email').focus() ;
     counter=1;
 }

   document.getElementById('course').innerHTML="";
  if(Course== "-1")
  {
    document.getElementById('course').innerHTML="Course you want to enroll" 
    document.getElementById('Course').focus();
    counter=1;
  }

/*----------------------------------------------------------------------------*/

var City=document.getElementById('City').value
var District=document.getElementById('District').value
var State=document.getElementById('State').value
var Pincode=document.getElementById('Pincode').value

  /*if ( ( StudentRegistration.sex[0].checked == false ) && ( StudentRegistration.sex[1].checked == false ) && ( StudentRegistration.sex[2].checked == false ))
  {
    document.getElementById('sex').innerHTML="**Please fill your Sex"
    return false;
  } */
  document.getElementById('pincode').innerHTML="";
  if(Pincode==""|| isNaN(Pincode) || Pincode.length!=6)
  {
    document.getElementById('pincode').innerHTML="Pincode should be in ######." 
    document.getElementById('Pincode').focus();
    counter=1;
  }
   
   document.getElementById('state').innerHTML="";
   if(State=="-1")
   {
    document.getElementById('state').innerHTML="**Please fill State";
    document.getElementById('State').focus(); 
    counter=1;
   }
   
   document.getElementById('district').innerHTML="";
   if( District=="" || District==null)
   {
    document.getElementById('district').innerHTML="**Please fill District";
    document.getElementById('District').focus();
    counter=1;
   }

   document.getElementById('city').innerHTML="";
   if( City=="" || City==null)
    {
     document.getElementById('city').innerHTML="**Please fill City";
     document.getElementById('City').focus(); 
     counter=1;
    }   

/*-------------------------------------------------------------------*/

  document.getElementById('personaladdr').innerHTML="";
  if(personal=="" || personal==null)
  { 
    document.getElementById('personaladdr').innerHTML="**Please fill Personal address";
    document.getElementById('personaladdress').focus();
    counter=1;
  }

  document.getElementById('fname').innerHTML="";
  if(fname=="" || fname==null)
  { 
    document.getElementById('fname').innerHTML="**Please fill Fathers name";
    document.getElementById('fathername').focus();
    counter=1;
  }

  if(!isNaN(fname) && fname!="")
  {
    document.getElementById('fname').innerHTML="**Only Characters are allowed";
    counter=1;
  }

  document.getElementById('username').innerHTML="";
if(user==""|| user==null)
{
  document.getElementById('username').innerHTML="**Please fill name";
  document.getElementById('name').focus();
  counter=1;
}
if(!isNaN(user) && user!="")
{
  document.getElementById('username').innerHTML="**Only Characters are allowed";
  counter=1;
}

  /*------------------------------------------------------*/
if(counter==1)
  return false;
else
{
  alert('Registration Successfull');
  return true;}
}